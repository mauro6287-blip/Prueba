'use client'

import { useState, useEffect } from 'react'
import { PDFUploader } from '@/components/PDFUploader'
import { FlipBook } from '@/components/FlipBook'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ArrowLeft, FileText, AlertCircle } from 'lucide-react'

// Importar PDF.js dinámicamente para evitar problemas de SSR
let pdfjsLib: any
if (typeof window !== 'undefined') {
  pdfjsLib = require('pdfjs-dist')
  // Configurar el worker usando una URL relativa que funcione en cualquier entorno
  pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.js'
}

export default function Home() {
  const [pdfPages, setPdfPages] = useState<string[]>([])
  const [fileName, setFileName] = useState<string>('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string>('')

  // Verificar que el entorno esté listo
  useEffect(() => {
    if (typeof window !== 'undefined') {
      console.log('Entorno de cliente detectado')
      console.log('PDF.js disponible:', !!pdfjsLib)
      if (pdfjsLib) {
        console.log('Versión de PDF.js:', pdfjsLib.version || 'desconocida')
      }
    }
  }, [])

  const processPDFInClient = async (pdfBase64: string, fileName: string) => {
    try {
      setIsLoading(true)
      
      // Verificar que PDF.js esté disponible
      if (!pdfjsLib || typeof window === 'undefined') {
        throw new Error('PDF.js no está disponible en este entorno')
      }
      
      console.log('Iniciando procesamiento del PDF en el cliente...')
      console.log('PDF.js versión:', pdfjsLib.version || 'desconocida')
      
      // Extraer el base64 del data URL
      const base64Data = pdfBase64.split(',')[1]
      if (!base64Data) {
        throw new Error('No se pudo extraer el base64 del PDF')
      }
      
      const binaryData = atob(base64Data)
      const bytes = new Uint8Array(binaryData.length)
      
      for (let i = 0; i < binaryData.length; i++) {
        bytes[i] = binaryData.charCodeAt(i)
      }
      
      console.log('Datos del PDF preparados, tamaño:', bytes.length)
      
      // Cargar el PDF con configuración básica para evitar problemas de recursos externos
      const loadingTask = pdfjsLib.getDocument({ 
        data: bytes,
        disableRange: true,
        disableStream: true,
        disableAutoFetch: true
      })
      
      console.log('Cargando PDF...')
      const pdf = await loadingTask.promise
      const numPages = pdf.numPages
      
      console.log(`PDF cargado exitosamente. Total de páginas: ${numPages}`)
      
      const pages: string[] = []
      
      // Procesar cada página con mejor manejo de errores
      for (let pageNum = 1; pageNum <= numPages; pageNum++) {
        try {
          console.log(`Procesando página ${pageNum} de ${numPages}...`)
          
          const page = await pdf.getPage(pageNum)
          const viewport = page.getViewport({ scale: 1.5 }) // Reducir escala para mejor rendimiento
          
          console.log(`Viewport de página ${pageNum}:`, viewport.width, 'x', viewport.height)
          
          // Crear canvas
          const canvas = document.createElement('canvas')
          const context = canvas.getContext('2d')
          
          if (!context) {
            throw new Error(`No se pudo obtener el contexto del canvas para la página ${pageNum}`)
          }
          
          canvas.height = viewport.height
          canvas.width = viewport.width
          
          // Establecer fondo blanco
          context.fillStyle = 'white'
          context.fillRect(0, 0, canvas.width, canvas.height)
          
          // Renderizar la página
          console.log(`Renderizando página ${pageNum}...`)
          await page.render({
            canvasContext: context,
            viewport: viewport
          }).promise
          
          console.log(`Página ${pageNum} renderizada correctamente`)
          
          // Convertir a base64
          const imageData = canvas.toDataURL('image/jpeg', 0.8) // Usar JPEG para mejor rendimiento
          pages.push(imageData)
          
          console.log(`Página ${pageNum} convertida a imagen`)
          
          // Pequeña pausa para no bloquear la UI
          if (pageNum % 2 === 0) {
            await new Promise(resolve => setTimeout(resolve, 50))
          }
        } catch (pageError) {
          console.error(`Error en página ${pageNum}:`, pageError)
          
          // Crear página de error
          const canvas = document.createElement('canvas')
          const context = canvas.getContext('2d')
          
          if (context) {
            canvas.height = 733
            canvas.width = 550
            
            context.fillStyle = 'white'
            context.fillRect(0, 0, canvas.width, canvas.height)
            context.fillStyle = 'black'
            context.font = '16px Arial'
            context.textAlign = 'center'
            context.fillText(`Error en página ${pageNum}`, canvas.width / 2, canvas.height / 2)
            
            pages.push(canvas.toDataURL('image/jpeg', 0.8))
          } else {
            // Si no hay contexto, crear una imagen de error mínima
            pages.push('data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAX/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCdABmX/9k=')
          }
        }
      }
      
      console.log('Procesamiento completado. Total de páginas procesadas:', pages.length)
      setPdfPages(pages)
      setFileName(fileName)
      
    } catch (error) {
      console.error('Error detallado al procesar PDF en cliente:', error)
      console.error('Tipo de error:', typeof error)
      console.error('Mensaje:', error instanceof Error ? error.message : 'Error desconocido')
      console.error('Stack:', error instanceof Error ? error.stack : 'No stack disponible')
      
      alert(`Error al procesar el PDF: ${error instanceof Error ? error.message : 'Error desconocido'}. Por favor, intenta de nuevo.`)
    } finally {
      setIsLoading(false)
    }
  }

  const handleFileUpload = async (file: File) => {
    setIsLoading(true)
    setError('')
    setFileName(file.name)

    try {
      // Verificar que el entorno esté listo
      if (typeof window === 'undefined') {
        throw new Error('El entorno no está disponible')
      }

      if (!pdfjsLib) {
        throw new Error('PDF.js no está cargado. Por favor, recarga la página.')
      }

      console.log('Iniciando proceso de subida...')
      
      // Crear FormData para enviar el archivo
      const formData = new FormData()
      formData.append('pdf', file)

      // Enviar el archivo al servidor para validación
      const response = await fetch('/api/convert-pdf', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || errorData.details || 'Error al procesar el PDF')
      }

      const data = await response.json()
      console.log('Respuesta del servidor recibida:', data)
      
      // Procesar el PDF en el cliente
      await processPDFInClient(data.pdfBase64, data.fileName)
      
    } catch (error) {
      console.error('Error:', error)
      const errorMessage = error instanceof Error ? error.message : 'Error al procesar el PDF. Por favor, intenta de nuevo.'
      setError(errorMessage)
      alert(errorMessage)
      setIsLoading(false)
    }
  }

  const handleBackToUpload = () => {
    setPdfPages([])
    setFileName('')
    setError('')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4">
      <div className="container mx-auto py-8">
        {pdfPages.length === 0 ? (
          <div className="space-y-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                PDF a Libro Virtual
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Transforma tus documentos PDF en libros interactivos con efectos 3D realistas. 
                Ideal para catálogos, revistas, presentaciones y más.
              </p>
            </div>
            
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {error}
                </AlertDescription>
              </Alert>
            )}
            
            <PDFUploader 
              onFileUpload={handleFileUpload} 
              isLoading={isLoading}
            />
            
            <div className="text-center text-sm text-gray-500">
              <p>Si encuentras problemas, intenta recargar la página o usar un navegador diferente.</p>
              <p className="mt-1">Recomendado: Chrome, Firefox o Safari.</p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={handleBackToUpload}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Subir otro PDF
              </Button>
              
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-gray-500" />
                <span className="font-medium">{fileName}</span>
              </div>
            </div>
            
            <FlipBook pdfPages={pdfPages} fileName={fileName} />
          </div>
        )}
      </div>
    </div>
  )
}