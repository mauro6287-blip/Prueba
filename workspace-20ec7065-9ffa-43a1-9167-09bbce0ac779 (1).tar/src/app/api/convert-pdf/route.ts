import { NextRequest, NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('pdf') as File

    if (!file) {
      return NextResponse.json(
        { error: 'No se proporcionó ningún archivo PDF' },
        { status: 400 }
      )
    }

    if (file.type !== 'application/pdf') {
      return NextResponse.json(
        { error: 'El archivo debe ser un PDF' },
        { status: 400 }
      )
    }

    // Verificar el tamaño del archivo (10MB máximo para esta versión simplificada)
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json(
        { error: 'El archivo PDF es demasiado grande. Máximo 10MB para esta versión.' },
        { status: 400 }
      )
    }

    console.log('Procesando PDF:', file.name, 'tamaño:', file.size)

    // Convertir el archivo a base64 para procesamiento en el cliente
    const arrayBuffer = await file.arrayBuffer()
    const base64 = Buffer.from(arrayBuffer).toString('base64')
    
    console.log('PDF convertido a base64, longitud:', base64.length)

    // Devolver el PDF en base64 para que el cliente lo procese
    return NextResponse.json({
      success: true,
      pdfBase64: `data:application/pdf;base64,${base64}`,
      fileName: file.name,
      fileSize: file.size,
      message: 'PDF listo para procesar en el cliente'
    })
  } catch (error) {
    console.error('Error al procesar el PDF:', error)
    return NextResponse.json(
      { 
        error: 'Error al procesar el archivo PDF',
        details: error instanceof Error ? error.message : 'Error desconocido'
      },
      { status: 500 }
    )
  }
}