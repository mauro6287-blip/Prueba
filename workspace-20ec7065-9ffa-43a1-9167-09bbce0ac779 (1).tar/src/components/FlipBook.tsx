'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  Maximize, 
  Minimize,
  Loader2
} from 'lucide-react'

interface FlipBookProps {
  pdfPages: string[]
  fileName: string
}

export function FlipBook({ pdfPages, fileName }: FlipBookProps) {
  const [currentPage, setCurrentPage] = useState(0)
  const [zoom, setZoom] = useState(1)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [loading, setLoading] = useState(true)
  const [isFlipping, setIsFlipping] = useState(false)
  const [flipDirection, setFlipDirection] = useState<'left' | 'right'>('right')
  const [windowHeight, setWindowHeight] = useState(0)

  useEffect(() => {
    if (pdfPages.length > 0) {
      setLoading(false)
    }
  }, [pdfPages])

  useEffect(() => {
    // Actualizar la altura de la ventana cuando cambie el tamaño
    const updateHeight = () => {
      setWindowHeight(window.innerHeight)
    }
    
    if (typeof window !== 'undefined') {
      setWindowHeight(window.innerHeight)
      window.addEventListener('resize', updateHeight)
    }
    
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('resize', updateHeight)
      }
    }
  }, [])

  const goToPreviousPage = () => {
    if (currentPage > 0 && !isFlipping) {
      setIsFlipping(true)
      setFlipDirection('left')
      setTimeout(() => {
        setCurrentPage(prev => prev - 1)
        setIsFlipping(false)
      }, 300)
    }
  }

  const goToNextPage = () => {
    if (currentPage < pdfPages.length - 1 && !isFlipping) {
      setIsFlipping(true)
      setFlipDirection('right')
      setTimeout(() => {
        setCurrentPage(prev => prev + 1)
        setIsFlipping(false)
      }, 300)
    }
  }

  const goToPage = (page: number) => {
    if (page >= 0 && page < pdfPages.length && !isFlipping) {
      setIsFlipping(true)
      setFlipDirection(page > currentPage ? 'right' : 'left')
      setTimeout(() => {
        setCurrentPage(page)
        setIsFlipping(false)
      }, 300)
    }
  }

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 0.2, 3))
  }

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 0.2, 0.5))
  }

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      const elem = document.documentElement
      if (elem.requestFullscreen) {
        elem.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }
    setIsFullscreen(!isFullscreen)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[600px]">
        <Loader2 className="w-12 h-12 animate-spin" />
      </div>
    )
  }

  const pageVariants = {
    enter: (direction: 'left' | 'right') => ({
      x: direction === 'right' ? 1000 : -1000,
      opacity: 0,
      rotateY: direction === 'right' ? -90 : 90
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      rotateY: 0
    },
    exit: (direction: 'left' | 'right') => ({
      zIndex: 0,
      x: direction === 'right' ? -1000 : 1000,
      opacity: 0,
      rotateY: direction === 'right' ? 90 : -90
    })
  }

  return (
    <div className="w-full space-y-4 px-2 sm:px-0">
      {/* Controles */}
      <Card className="border-0 shadow-none">
        <CardContent className="p-2 sm:p-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={goToPreviousPage}
                disabled={currentPage === 0 || isFlipping}
                className="shrink-0"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={currentPage + 1}
                  onChange={(e) => goToPage(parseInt(e.target.value) - 1)}
                  className="w-16 text-center text-sm"
                  min={1}
                  max={pdfPages.length}
                  disabled={isFlipping}
                />
                <span className="text-sm text-gray-500 whitespace-nowrap">
                  de {pdfPages.length}
                </span>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={goToNextPage}
                disabled={currentPage === pdfPages.length - 1 || isFlipping}
                className="shrink-0"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomOut}
                disabled={zoom <= 0.5}
                className="shrink-0"
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              
              <span className="text-sm text-gray-500 min-w-[3rem] text-center">
                {Math.round(zoom * 100)}%
              </span>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleZoomIn}
                disabled={zoom >= 3}
                className="shrink-0"
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={toggleFullscreen}
                className="shrink-0"
              >
                {isFullscreen ? (
                  <Minimize className="w-4 h-4" />
                ) : (
                  <Maximize className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FlipBook */}
      <Card className="border-0 shadow-none">
        <CardContent className="p-0">
          <div className="flex justify-center">
            <div 
              className="relative shadow-lg w-full"
              style={{
                height: `${Math.min(733 * zoom, windowHeight * 0.8)}px`,
                maxWidth: '100%',
                perspective: '2000px'
              }}
            >
              <AnimatePresence mode="wait" custom={flipDirection}>
                <motion.div
                  key={currentPage}
                  custom={flipDirection}
                  variants={pageVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{
                    x: { type: "spring", stiffness: 300, damping: 30 },
                    opacity: { duration: 0.2 },
                    rotateY: { duration: 0.3 }
                  }}
                  className="absolute inset-0 w-full h-full"
                  style={{
                    transformStyle: 'preserve-3d',
                    backfaceVisibility: 'hidden'
                  }}
                >
                  <img
                    src={pdfPages[currentPage]}
                    alt={`Página ${currentPage + 1}`}
                    className="w-full h-full object-contain bg-white"
                    draggable={false}
                    style={{ 
                      transform: 'translateZ(1px)',
                      maxHeight: '100%',
                      maxWidth: '100%'
                    }}
                  />
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Miniaturas */}
      <Card className="border-0 shadow-none mt-4">
        <CardContent className="p-2">
          <h3 className="text-lg font-semibold mb-2 text-center">Miniaturas</h3>
          <div className="flex gap-1 overflow-x-auto pb-2 justify-center sm:justify-start">
            {pdfPages.map((page, index) => (
              <button
                key={index}
                onClick={() => goToPage(index)}
                disabled={isFlipping}
                className={`flex-shrink-0 border-2 rounded transition-all ${
                  currentPage === index
                    ? 'border-primary shadow-lg scale-105'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <img
                  src={page}
                  alt={`Miniatura página ${index + 1}`}
                  className="w-12 h-16 sm:w-16 sm:h-20 object-cover"
                  draggable={false}
                />
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}